#ifndef PART3_H
#define PART3_H

#include "sm2.h"

void test_part3(char **sm2_param, int type, int point_bit_length);

#endif;
