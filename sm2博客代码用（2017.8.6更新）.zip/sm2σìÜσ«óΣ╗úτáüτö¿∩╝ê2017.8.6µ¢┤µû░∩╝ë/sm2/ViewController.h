//
//  ViewController.h
//  sm2
//
//  Created by yfc on 16/7/11.
//  Copyright © 2016年 yfc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

