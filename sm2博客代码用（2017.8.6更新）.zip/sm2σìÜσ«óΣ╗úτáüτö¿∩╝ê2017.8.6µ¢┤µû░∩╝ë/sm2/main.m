//
//  main.m
//  sm2
//
//  Created by yfc on 16/7/11.
//  Copyright © 2016年 yfc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
